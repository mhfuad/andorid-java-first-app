package com.fuad.firstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private EditText name;
    private Button submit;

    private TextView responseTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.editText);
        responseTextView = findViewById(R.id.editText);
        submit = findViewById(R.id.button);

        String apiUrl = "https://64a40253c3b509573b56ea44.mockapi.io/users";
        new ApiCallTask().execute(apiUrl);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameText = name.getText().toString();
                Toast.makeText(MainActivity.this, "Entered text: "+ nameText, Toast.LENGTH_LONG).show();
            }
        });
    }

    private class ApiCallTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String apiUrl = params[0];
            return fetchData(apiUrl);
        }

        protected void onPostExecute(String response){
            if (response != null){
                responseTextView.setText(response);
            }else{
                responseTextView.setText("Error occurred");
            }
        }

        private String fetchData(String apiUrl) {
            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(apiUrl)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    return response.body().string();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }
}